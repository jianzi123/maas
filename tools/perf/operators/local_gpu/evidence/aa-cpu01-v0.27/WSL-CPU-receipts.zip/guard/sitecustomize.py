import sys,importlib.abc
class CPUOnly(importlib.abc.MetaPathFinder):
 def find_spec(self,fullname,path=None,target=None):
  if fullname.split('.')[0] in {'torch','sglang','pynvml','aa_runtime'}:raise RuntimeError('FORBIDDEN_GPU_IMPORT')
sys.meta_path.insert(0,CPUOnly())
def protect(event,args):
 if event=='open' and str(args[0]).endswith('gpu0-research.lock'):raise RuntimeError('FORBIDDEN_SHARED_LOCK')
 if event=='subprocess.Popen' and 'nvidia-smi' in str(args):raise RuntimeError('FORBIDDEN_GPU_QUERY')
sys.addaudithook(protect)
