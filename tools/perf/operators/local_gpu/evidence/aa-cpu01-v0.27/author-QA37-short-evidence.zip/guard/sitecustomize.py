import sys,importlib.abc
class CPUOnly(importlib.abc.MetaPathFinder):
 def find_spec(self,fullname,path=None,target=None):
  if fullname.split('.')[0] in {'torch','sglang','pynvml','aa_runtime'}:raise RuntimeError('QA forbidden GPU import')
sys.meta_path.insert(0,CPUOnly())
def audit(event,args):
 if event=='open' and str(args[0]).endswith('gpu0-research.lock'):raise RuntimeError('QA forbidden shared lock')
 if event=='subprocess.Popen' and 'nvidia-smi' in str(args):raise RuntimeError('QA forbidden resource query')
sys.addaudithook(audit)
