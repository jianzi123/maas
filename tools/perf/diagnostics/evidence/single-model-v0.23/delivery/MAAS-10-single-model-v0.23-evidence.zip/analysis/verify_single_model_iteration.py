from pathlib import Path
import json,shutil,subprocess,sys,hashlib
out=Path("deliverables/single-model-v0.23");out.mkdir(parents=True,exist_ok=True)
source=Path("deliverables/elit01-v0.22")
original=json.loads((source/"R01/gates.json").read_text())
expected={"both_empty":"requires logits and KV","native_empty":"requires logits and KV",
          "mature_empty":"requires logits and KV","asymmetric":"requires logits and KV",
          "missing_variant":"variants incomplete","swapped_roles":"full logits role/shape/dtype"}
cases=[]
for name,message in expected.items():
 root=out/"gate-negative-cases"/name;root.mkdir(parents=True,exist_ok=False)
 shutil.copytree(source/"R01",root/"R01")
 gates=json.loads(json.dumps(original));snap=gates[0]["snapshots"]
 if name=="both_empty":gates[0]["snapshots"]={"native":[],"mature":[]}
 elif name=="native_empty":snap["native"]=[]
 elif name=="mature_empty":snap["mature"]=[]
 elif name=="asymmetric":snap["mature"]=snap["mature"][:1]
 elif name=="missing_variant":snap.pop("mature")
 elif name=="swapped_roles":snap["native"].reverse()
 (root/"R01/gates.json").write_text(json.dumps(gates))
 dest=root/"must-not-exist.json"
 cmd=[sys.executable,"repo/tools/perf/operators/local_gpu/analyze_kv_cadence.py","--plan",str(source/"plan.json"),"--root",str(root),"--output",str(dest)]
 p=subprocess.run(cmd,capture_output=True,text=True)
 (root/"refusal.log").write_text(p.stderr,encoding="utf-8")
 assert p.returncode!=0 and message in p.stderr and not dest.exists(),(name,p.stderr)
 cases.append({"case":name,"exit":p.returncode,"expected_error":message,"success_report_absent":True})
strict=json.loads((source/"strict-analysis-v2.json").read_text())
old=json.loads((source/"analysis.json").read_text())
for key in ("block_status_counts","clusters","triplets","planned_blocks","planned_calls"):
 assert strict[key]==old[key],key
shutil.copyfile(source/"strict-analysis-v2.json",out/"strict-analysis-v2.json")
record={"issue":"ELIT-QA-01","cases":cases,"valid_original_reanalyzed":True,"all_numeric_outcomes_unchanged":True,
 "original_plan_file_sha256":hashlib.sha256((source/"plan.json").read_bytes()).hexdigest(),
 "original_plan_canonical_sha256":strict["plan_sha256"],"full_qualified_triplets":0,"full_triplets":18,
 "GPU_experiments_this_run":0}
(out/"gate-fix-verification.json").write_text(json.dumps(record,indent=2)+"\n")
# Actual command-line client capture through an owned loopback HTTP server.
sys.path.insert(0,str(Path("repo/tools/perf/diagnostics").resolve()))
from test_client_capture import server,manifest
client=[]
for mode in ("content","error_after","cancel","reject"):
 folder=out/"controlled-client"/mode;folder.mkdir(parents=True,exist_ok=False)
 with server(mode) as url:
  m=manifest(url)
  (folder/"manifest.json").write_text(json.dumps(m))
  (folder/"body.json").write_text(json.dumps({"stream":True,"model":"controlled-test"}))
  cmd=[sys.executable,"repo/tools/perf/diagnostics/client_capture.py","--manifest",str(folder/"manifest.json"),
      "--body-file",str(folder/"body.json"),"--output",str(folder/"client-source.json"),
      "--execute","--approval-ref","controlled-test"]
  if mode=="cancel":cmd.append("--stop-after-content")
  p=subprocess.run(cmd,capture_output=True,text=True);assert p.returncode==0,p.stderr
  (folder/"command.json").write_text(json.dumps(cmd,indent=2)+"\n")
  (folder/"stdout.log").write_text(p.stdout)
 r=json.loads((folder/"client-source.json").read_text())
 assert "SECRET" not in json.dumps(r)
 client.append({"mode":mode,"termination":r["termination"],"first_protocol_ms":r["first_protocol_data_ms"],
     "first_content_ms":r["first_content_received_ms"],"observed_request_id":r["request_id"],
     "source":"owned Python loopback HTTP, not Go/Higress/model","Go_runtime_this_capture":False})
(out/"controlled-client-verification.json").write_text(json.dumps({"source_kind":"controlled_loopback",
 "records":client,"protected_product_chain_executed":False,"client_unit_tests":14,"cadence_metadata_tests":33},indent=2)+"\n")
print(json.dumps({"gate_CLI_refusals":len(cases),"original_numerics_unchanged":True,
 "controlled_client_CLI_records":len(client),"GPU_experiments":0}))
