from pathlib import Path
import json,hashlib,subprocess,sys,ast,re,html
from urllib.parse import urlparse,unquote
root=Path("repo");out=Path("deliverables/single-model-v0.23")
# Check read-only historical summary compatibility too.
cmd=[sys.executable,"repo/tools/perf/operators/local_gpu/summarize_kv_cadence.py","--plan","deliverables/elit01-v0.22/plan.json",
 "--root","deliverables/elit01-v0.22","--analysis",str(out/"strict-analysis-v2.json"),"--output",str(out/"strict-stratified-summary.json")]
p=subprocess.run(cmd,capture_output=True,text=True)
(out/"summary-compatibility.log").write_text(p.stdout+p.stderr)
assert p.returncode==0,p.stderr
summary=json.loads((out/"strict-stratified-summary.json").read_text())
assert summary["fully_gap_matched_full_triplets"]==0
new_files=["tools/perf/diagnostics/client_capture.py","tools/perf/diagnostics/associate_client_relay.py",
 "tools/perf/diagnostics/test_client_capture.py","tools/perf/operators/local_gpu/analyze_kv_cadence.py",
 "tools/perf/operators/local_gpu/test_cadence_gates.py","tools/perf/operators/local_gpu/summarize_kv_cadence.py"]
for f in new_files:ast.parse((root/f).read_text(encoding="utf-8"))
links=0
for p in (root/"docs/performance").rglob("*.md"):
 for target in re.findall(r"!?\[[^\]]*\]\(([^)]+)\)",p.read_text(encoding="utf-8")):
  u=urlparse(target)
  if u.scheme:continue
  dest=(p.parent/unquote(u.path)).resolve() if u.path else p
  assert dest.exists(),(p,target);links+=1
for f in ("cadence_protocol.py","bench_kv_cadence.py","bench_kv_interleaved.py","bench_native_kv.py","native_kv_binding.py","run_decode.py"):
 path="tools/perf/operators/local_gpu/"+f
 assert (root/path).read_bytes()==subprocess.check_output(["git","-C",str(root),"show","5f8bd5d:"+path])
legacy=root/"tools/perf/operators/local_gpu/legacy_source/analyze_kv_cadence.v0.22.py.txt"
assert legacy.read_bytes()==subprocess.check_output(["git","-C",str(root),"show","5f8bd5d:tools/perf/operators/local_gpu/analyze_kv_cadence.py"])
for name in ("client_capture.py","associate_client_relay.py"):
 r=subprocess.run([sys.executable,str(root/"tools/perf/diagnostics"/name),"--help"],capture_output=True,text=True);assert r.returncode==0
 (out/(name+".help.txt")).write_text(r.stdout)
r=subprocess.run([sys.executable,"repo/tools/perf/diagnostics/client_capture.py","--manifest","repo/tools/perf/diagnostics/single-model-client-plan.template.json"],capture_output=True,text=True)
assert r.returncode==2
(out/"disabled-template-rejection.log").write_text(r.stdout+r.stderr)
verification={"scope":"targeted implementation/transport validation, not model performance",
 "cadence_gate_metadata_tests":36,"real_gate_CLI_refusals":6,"original_numerics_unchanged":True,
 "client_protocol_tests":18,"controlled_client_CLI_records":4,"source_links":links,
 "syntax_files":len(new_files),"legacy_analyzer_exact":True,"GPU_producer_sources_unchanged":True,
 "protected_product_path_executed":False,"new_GPU_experiments":0,
 "missing_approved_template_rejected_before_request":True}
(out/"verification.json").write_text(json.dumps(verification,indent=2)+"\n")
ev=root/"tools/perf/diagnostics/evidence/single-model-v0.23";ev.mkdir(parents=True,exist_ok=True)
for name in ("verification.json","gate-fix-verification.json","controlled-client-verification.json","dependency-handoff.json"):
 (ev/name).write_bytes((out/name).read_bytes())
for mode in ("content","error_after","cancel","reject"):
 (ev/(mode+"-client-source.json")).write_bytes((out/"controlled-client-final"/mode/"client-source.json").read_bytes())
# Human report contains statuses only, not a loopback-to-model timing comparison.
clients=json.loads((out/"controlled-client-verification.json").read_text())["records"]
table="<table><tr><th>受控模式</th><th>termination</th><th>首内容已观测</th><th>来源</th></tr>"+"".join(
 "<tr><td>"+html.escape(r["mode"])+"</td><td>"+html.escape(r["termination"])+"</td><td>"+str(r["first_content_ms"] is not None)+"</td><td>owned loopback HTTP</td></tr>" for r in clients)+"</table>"
body="<h1>单模型采集接线与ELIT-QA-01修复</h1><aside>旧0.22数值与Full因果资格0/18保持；新分析器拒绝空/缺失/不对称向量。产品受保护链路未执行，本轮新增记录仅验证自有HTTP客户端协议。</aside>"
body+="<h2 id='graph'>完整向量门禁</h2><p>每variant恰为完整FP32 logits＋全30层FP16 K/V。双空、单空、不对称、缺variant、交换角色经真实CLI均非0/无成功报告。36项回归含双方相同截断/错误位宽/缺层也拒绝。</p><p>正确原件1080块复算通过。旧plan/阈值不改；只将已知历史分析器hash与归档原字节核对后升级离线验证，其他producer源码仍严格匹配。</p>"
body+="<h2 id='equivalence'>实际客户端HTTP验证</h2><p>read1、增量UTF8/SSE完整事件；首协议data与首个非空delta.content分开。18项测试涵盖role/空content/usage、内容后error、EOF、停止、超时和时钟拒绝。源输出不含内容/Key，事件数不当token，停止不当服务端ACK。</p>"+table
body+="<h2 id='cost'>产品侧的真实缺口</h2><p>MAAS-3单一后端主线仍在补受保护模型/Higress/adapter，旧4179仅历史管理链路且过期。MAAS-8新PR13组合因缺失/未批准输入拒绝就绪。当前没有获准端点/平台Key与同run Go export，client-Go仅能做未验证request关联，不合并时钟，Worker/真实usage未知。</p><p>具体原角色输入已列dependency-handoff.json：Go/Higress受保护入口与原ID用量；一致运行组合/boot；模型profile/额度/预算/SLO；trace/full binding与时钟校准或provider不可观测证明。</p>"
body+="<h2 id='limits'>范围与下一步</h2><p>本轮没有GPU补样、供应商调用、权重下载、目标部署或产品内核改动。已有GPU研究授权保持，旧成熟算子/ModelRunner证据按原SHA保留，稳定收益仍unknown。MAAS-18完整描述CLI读取失败；已读项目最新描述、直接交接与MAAS-3/8线程，不声称读全未取回细项。</p><p>下一步源端由MAAS-3/8接通，消费端按真实request/run/instance/boot和clock逐项校验；新GPU参考小窗仍先冻结与holdout，不重跑旧1080块或以本HTTP测试宣布模型收益。</p>"
css="body{font:16px/1.8 system-ui,'Microsoft YaHei',sans-serif;max-width:1200px;margin:28px auto;padding:0 25px;color:#17384b;background:#f5f8fb}aside{background:#fff0d5;padding:16px;border-left:5px solid #ad7526}h2{border-bottom:2px solid #ccdde7;margin-top:32px}table{border-collapse:collapse;background:white;width:100%;font-size:14px}td,th{padding:10px;border:1px solid #c5d6df}nav a{margin-right:20px}"
nav="<nav>"+"".join("<a href='#"+s+"'>"+t+"</a>" for s,t in (("graph","原件门禁"),("equivalence","客户端"),("cost","接线缺口"),("limits","范围")))+"</nav>"
(out/"MAAS-10-single-model-iteration.html").write_text("<!doctype html><html lang='zh-CN'><meta charset='utf-8'><title>单模型采集与原件门禁</title><style>"+css+"</style><body>"+nav+body+"</body></html>",encoding="utf-8")
print(json.dumps(verification))
s=Path("verify_window_b_browser.py").read_text().replace("deliverables/window-b-v0.20","deliverables/single-model-v0.23").replace("MAAS-10-window-B.html","MAAS-10-single-model-iteration.html").replace("window-b-browser","single-model-browser")
Path("verify_single_model_browser.py").write_text(s,encoding="utf-8",newline="\n")
