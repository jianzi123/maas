from pathlib import Path
import zipfile,json,hashlib,subprocess,sys
out=Path("deliverables/single-model-v0.23")
with zipfile.ZipFile("deliverables/d1-v0.13/MAAS-10-D1-evidence-v0.13.zip") as z:
 raw=z.read("original-source/go-relay-d1.json")
 manifest=z.read("original-source/go-relay-d1-manifest.json")
d=json.loads(raw);sample=d["samples"][0]
go=out/"prior-Go-derived-sample.json";go.write_text(json.dumps(sample,indent=2)+"\n")
sha=hashlib.sha256(go.read_bytes()).hexdigest()
dest=out/"must-not-associate-prior-Go.json"
cmd=[sys.executable,"repo/tools/perf/diagnostics/associate_client_relay.py",
 "--client-source",str(out/"controlled-client-final/content/client-source.json"),
 "--go-sample",str(go),"--expected-go-sha256",sha,"--output",str(dest)]
p=subprocess.run(cmd,capture_output=True,text=True)
assert p.returncode==2 and not dest.exists(),p.stdout
(out/"historical-Go-association-rejection.log").write_text(p.stdout+p.stderr)
(out/"historical-Go-association-verification.json").write_text(json.dumps({
 "scope":"negative association test, not actual client-Go joined request",
 "parent_export_sha256":hashlib.sha256(raw).hexdigest(),"parent_manifest_sha256":hashlib.sha256(manifest).hexdigest(),
 "derived_single_sample_sha256":sha,"source_archive":"D1 v0.13 original controlled Go evidence",
 "different_actual_request_ids":sample["request_id"]!=json.loads((out/"controlled-client-final/content/client-source.json").read_text())["request_id"],
 "CLI_exit":p.returncode,"successful_association_file_absent":True,"new_Go_or_GPU_run":False},indent=2)+"\n")
print(json.dumps({"historical_Go_new_client_mismatch_rejected":True,"exit":p.returncode}))
