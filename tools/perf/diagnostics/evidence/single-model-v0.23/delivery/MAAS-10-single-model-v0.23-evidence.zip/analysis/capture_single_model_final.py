from pathlib import Path
import json,subprocess,sys,hashlib
out=Path("deliverables/single-model-v0.23")
# Actual command-line client capture through an owned loopback HTTP server.
sys.path.insert(0,str(Path("repo/tools/perf/diagnostics").resolve()))
from test_client_capture import server,manifest
client=[]
for mode in ("content","error_after","cancel","reject"):
 folder=out/"controlled-client-final"/mode;folder.mkdir(parents=True,exist_ok=False)
 with server(mode) as url:
  m=manifest(url)
  (folder/"manifest.json").write_text(json.dumps(m))
  (folder/"body.json").write_text(json.dumps({"stream":True,"model":"controlled-test"}))
  cmd=[sys.executable,"repo/tools/perf/diagnostics/client_capture.py","--manifest",str(folder/"manifest.json"),
      "--body-file",str(folder/"body.json"),"--output",str(folder/"client-source.json"),
      "--execute","--approval-ref","controlled-test"]
  if mode=="cancel":cmd.append("--stop-after-content")
  p=subprocess.run(cmd,capture_output=True,text=True);assert p.returncode==0,p.stderr
  (folder/"command.json").write_text(json.dumps(cmd,indent=2)+"\n")
  (folder/"stdout.log").write_text(p.stdout)
 r=json.loads((folder/"client-source.json").read_text());assert r["collector_source_sha256"]==hashlib.sha256(Path("repo/tools/perf/diagnostics/client_capture.py").read_bytes()).hexdigest()
 assert "SECRET" not in json.dumps(r)
 client.append({"mode":mode,"termination":r["termination"],"first_protocol_ms":r["first_protocol_data_ms"],
     "first_content_ms":r["first_content_received_ms"],"observed_request_id":r["request_id"],
     "source":"owned Python loopback HTTP, not Go/Higress/model","Go_runtime_this_capture":False})
(out/"controlled-client-verification.json").write_text(json.dumps({"source_kind":"controlled_loopback",
 "records":client,"protected_product_chain_executed":False,"client_unit_tests":18,"cadence_metadata_tests":33},indent=2)+"\n")
print(json.dumps({"final_client_CLI_records":len(client),"client_source_hash_verified":True}))
