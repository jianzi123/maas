from pathlib import Path
import subprocess,json,time,urllib.request,websocket,base64,uuid

out=Path("deliverables/single-model-v0.23").resolve()
edge="C:/Program Files (x86)/Microsoft/Edge/Application/msedge.exe"
profile=out/("foundation-cdp-"+uuid.uuid4().hex[:8])
log=(out/"single-model-browser-cdp.log").open("w",encoding="utf-8")
proc=subprocess.Popen([edge,"--headless=new","--disable-gpu","--no-first-run",
    "--disable-background-networking","--disable-component-update","--disable-background-mode",
    "--remote-debugging-port=0","--remote-allow-origins=http://localhost",
    "--user-data-dir="+str(profile),"about:blank"],stdout=log,stderr=log)
ws=None
try:
    until=time.monotonic()+15
    port_file=profile/"DevToolsActivePort"
    while not port_file.exists():
        # Recent Edge launchers hand ownership to a compat-layer child.
        # The unique profile's DevToolsActivePort is the readiness source.
        launcher_status=proc.poll()
        if time.monotonic()>until:raise TimeoutError("DevTools port unavailable")
        time.sleep(0.1)
    port=port_file.read_text().splitlines()[0]
    with urllib.request.urlopen("http://127.0.0.1:"+port+"/json/list",timeout=3) as response:
        targets=json.load(response)
    target=next(t for t in targets if t["type"]=="page")
    ws=websocket.create_connection(target["webSocketDebuggerUrl"],origin="http://localhost",timeout=10)
    counter=0
    def rpc(method,params=None):
        global counter
        counter+=1;rid=counter
        ws.send(json.dumps({"id":rid,"method":method,"params":params or {}}))
        while True:
            msg=json.loads(ws.recv())
            if msg.get("id")==rid:
                if "error" in msg:raise RuntimeError(msg["error"])
                return msg.get("result",{})
    rpc("Page.enable")
    rpc("Emulation.setDeviceMetricsOverride",{"width":1440,"height":1100,"deviceScaleFactor":1,"mobile":False})
    rpc("Page.navigate",{"url":(out/"MAAS-10-single-model-iteration.html").as_uri()})
    rpc("Runtime.evaluate",{"expression":"document.fonts.ready.then(() => document.readyState)","awaitPromise":True,"returnByValue":True})
    layout=[]
    for slug in ["graph","equivalence","cost","limits"]:
        js="""(async () => {
          location.hash = SLUG;
          if(document.getElementById(SLUG).tagName==='DETAILS') document.getElementById(SLUG).open=true;
          document.getElementById(SLUG).scrollIntoView({behavior:'instant',block:'start'});
          await new Promise(resolve => requestAnimationFrame(() => requestAnimationFrame(resolve)));
          await new Promise(resolve => setTimeout(resolve, 150));
          let el = document.getElementById(SLUG), box = el.getBoundingClientRect();
          return {slug:SLUG,scrollY:scrollY,targetTop:box.top,
            maxScroll:document.documentElement.scrollHeight-innerHeight, heading:el.innerText, detailsOpen:el.tagName==='DETAILS'?el.open:null, width:innerWidth, height:innerHeight};
        })()""".replace("SLUG",json.dumps(slug))
        result=rpc("Runtime.evaluate",{"expression":js,"awaitPromise":True,"returnByValue":True})
        state=result["result"]["value"]
        assert abs(state["targetTop"])<=16 or (
            abs(state["scrollY"]-state["maxScroll"])<=2 and 0 <= state["targetTop"] < state["height"]-60
        ),state
        shot=rpc("Page.captureScreenshot",{"format":"png","captureBeyondViewport":False,"fromSurface":True})
        (out/("single-model-browser-"+slug+".png")).write_bytes(base64.b64decode(shot["data"]))
        layout.append(state)
    (out/"browser-layout.json").write_text(json.dumps(layout,ensure_ascii=False,indent=2)+"\n",encoding="utf-8")
    print(json.dumps({"browser_sections":layout},ensure_ascii=True))
finally:
    if ws:
        try:rpc("Browser.close")
        except (websocket.WebSocketConnectionClosedException,websocket.WebSocketTimeoutException):pass
        ws.close()
    try:proc.wait(timeout=5)
    except subprocess.TimeoutExpired:
        proc.terminate()
        proc.wait(timeout=5)
    log.close()
